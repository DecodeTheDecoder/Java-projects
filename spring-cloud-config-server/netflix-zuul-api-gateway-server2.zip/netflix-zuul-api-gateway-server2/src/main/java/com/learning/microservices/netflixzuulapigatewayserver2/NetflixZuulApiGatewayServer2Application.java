package com.learning.microservices.netflixzuulapigatewayserver2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NetflixZuulApiGatewayServer2Application {

	public static void main(String[] args) {
		SpringApplication.run(NetflixZuulApiGatewayServer2Application.class, args);
	}

}
